extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
	$audio_test.play()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_go_back_to_büro_pressed() -> void:
	get_tree().change_scene_to_file("res://Tutorial/Tutorial Szenes/tuto_investigator_buero.tscn")
